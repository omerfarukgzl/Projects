
public interface IObserver {

	void Update(boolean durum);
}
