
public interface ISıcaklikAlgila {

	void Sicaklik_goruntule();

}
