
public interface ISubject {

	void yetki_ver(IObserver o);

	void yetki_al(IObserver o);

	void bildirim();
	
	

}
